#!/bin/bash
cd /home/ec2-user
java -jar ContainerNetworkClient-1.0-SNAPSHOT.jar >/dev/null 2>&1